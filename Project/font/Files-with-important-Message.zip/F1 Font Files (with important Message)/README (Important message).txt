The Fonts dont have the original names (because i must converted it to otf files) but the files are the same like in TV
F1 Regular is Formula1 Display Regular
F1 Torque is Formula1 Display Bold
F1 Turbo is Formula1 Display Wide